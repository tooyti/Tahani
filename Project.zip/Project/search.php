
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" >
<head>	
	<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=iso-8859-1" />
	<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php session_start();?>
         <div id="header">
           
              <table align="center">
              <tr>
                  <td width="13%" align=center><a href="index.html"> Home  </a> </td>
                 <td width="16%" align=center><a href="Add.php">  Add Product  </a></td>
                 <td width="19%" align=center><a href="Search.php">Product Search  </a></td>
				 <td width="12%" align=center> <a href="Opnion.php"> Opnion  </a></td>
				 <td width="19%" align=center><a href="SearchOpnion.php"> Opnion Search </a></td>
				 <td width="16%" align=center><a href="about.html"> About</a></td>
              </tr>
              </table>
             
             </div>
	     
             <div id="content">
             <h2>
             Write product code to search:
              </h2>
			  
			 				 
              <form action = "<?php $_PHP_SELF ?>"  method="post" >
               <table width="558" border="0">
                 <tr>
                   <td width="82">Product Code</td>
                   <td width="466"><input name="code" type="text" size="50"/></td>
                 </tr>
                 <tr>
                   <td>&nbsp;</td>
                   <td><input   type="submit"  value="Send" />
                   <input  type="reset"   value="Reset"/></td>
                 </tr>
                 <tr>
                   <td>&nbsp;</td>
                   <td>
                   </td>
                   </tr>
                   </table>
                   </form>
                   <br/>
                  
				   <?php
		
				$mysqli=mysqli_connect("localhost","root","","project");
				if (mysqli_connect_errno()) 
				{
							printf("Connect failed: %s\n", mysqli_connect_error());
							exit();
				}
				else {
				  if(isset($_POST['code']))
				
				   {
						$code=$_POST['code'];
						$sql="select * from product where code='$code'";
						$res=mysqli_query($mysqli,$sql);
					    if(mysqli_num_rows($res)>0)
						{

							?>
								 <table border="1"  style="border-collapse:collapse;">
							     <tr><td width="120">Code</td><td width='120'>Product</td>
								 <td width='120'>Description</td><td width='120'>Photo</td></tr>
								<?php		
								while($newArray=mysqli_fetch_array($res,MYSQLI_ASSOC)) 
								{
		                         echo "<tr><td width='100' style='vertical-align: top;'>
								 <a href='update.php'/>". $newArray['code']."  Update Row
					                    </a></td>
										<td width='100' style='vertical-align: top;'>".$newArray['product']."</td>";
								  echo   "<td width='120' style='vertical-align: top;'>".$newArray['description']."</td>";
					              echo   "<td width=120>";
								  echo   "<img src='images/".$newArray['photo']."' width=300 height=250></td></tr>";
								  
								  $_SESSION['code'] = $newArray['code'];
							      $_SESSION['product'] = $newArray['product'];
							      $_SESSION['description']= $newArray['description'];
							   }
						       echo "</table>";
		               }
				     else
						 printf("Could not retrieve any products : %s\n",mysqli_error($mysqli));
				   }
				mysqli_close($mysqli);
			}
		
			?>
          
         
             </div>


</body>
</html>
