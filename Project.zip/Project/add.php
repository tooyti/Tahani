<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" >
<head>
	<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=iso-8859-1" />
	<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
                <div id="header">
           
              <table align="center">
              <tr>
                 <td width="13%" align=center><a href="index.html"> Home  </a> </td>
                 <td width="16%" align=center><a href="Add.php">  Add Product  </a></td>
                 <td width="19%" align=center><a href="Search.php">Product Search  </a></td>
				 <td width="12%" align=center> <a href="Opnion.php"> Opnion  </a></td>
				 <td width="19%" align=center><a href="SearchOpnion.php"> Opnion Search </a></td>
				 <td width="16%" align=center><a href="about.html"> About</a></td>
              </tr>
              </table>
             
             </div>
	     
              <div id="content">
              <h2>
				Add new product:
              </h2>
			  
              <form action = "<?php $_PHP_SELF ?>" method="post" name="add" enctype="multipart/form-data" 
			             onsubmit="return (check());">
                 <table width="800" border="0">
                 <tr>
                   <td width="122" height="42">Product Code</td>
                   <td width="511"><input name="code" type="text" size="50" id="code" /></td>
                 </tr>
                 <tr>
                   <td>Product</td>
                   <td><input name="product" type="text" size="50"  id="product"/></td>
                 </tr>
                 <tr>
                   <td>Description</td>
                   <td><input name="description" type="text" size="50"  id="description"/></td>
                 </tr>
                 
                 <tr>
                   <td width="122" height="42">Photo</td>
                   <td width="511"><input type="file" name="photo" id="photo"></td>
                 </tr>
                 
                  <tr>
                   <td>&nbsp;</td>
                   <td><input   type="submit"  value="Send" />  <input  type="reset"   value="Reset"/></td>
                 </tr>
                 
               </table>
              </form>
			
			<?php
			
			$mysqli=mysqli_connect("localhost","root","","project");
			if (mysqli_connect_errno()) 
			{
						printf("Connect failed: %s\n", mysqli_connect_error());
						exit();
			}
			else {
					if(isset($_POST['code']))
					{
						$code=$_POST['code'];
						$product=$_POST['product'];
						$description=$_POST['description'];
						
						$photo=$_FILES['photo']['name'];
						

						$sql = "INSERT INTO product  values('$code','$product','$description','$photo')";
						
						$res = mysqli_query($mysqli, $sql);
						if ($res === TRUE) 
						{
							echo "A new product has been inserted. ";
						}
						else 
						{ 
							 printf("Could not insert record: %s\n", mysqli_error($mysqli)); 
						}
				 }
				mysqli_close($mysqli);
			}
		
		?>
       
		 </div>  
		 
        <script type="text/javascript">
          function check(){
		      var code = document.add.code.value;
		      if (code=="") 
		      {
			     window.alert("write product code");
			     document.add.code.focus() ;
			     return false;
		      }
		   return( true );
	    }
	  </script>  	

</body>
</html>
